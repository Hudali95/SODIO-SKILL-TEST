import React, { Component } from 'react'
import 'bootstrap/dist/css/bootstrap.min.css';
import Register from './components/registerPage'
import Dashbord from './components/dashboard'
import {
  BrowserRouter as Router,
  Switch,
  Route,
  Link
} from "react-router-dom";

export class App extends Component {
  render() {
    return (
      <>
        <Router>
          <Switch>
            <Route exact path="/" >
              <Register />
            </Route>
            <Route path="/register" >
              <Register />
            </Route>
            <Route path="/dashbord" >
              <Dashbord />
            </Route>
          </Switch>
        </Router>

      </>
    )
  }
}

export default App
