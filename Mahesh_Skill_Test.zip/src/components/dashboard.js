import React, { Component } from 'react'
import { Container, Col, Row, Button, Form, Table } from 'react-bootstrap'
import Tab from 'react-bootstrap/Tab'
import Tabs from 'react-bootstrap/Tabs'
import Nav from 'react-bootstrap/Nav'
const axios = require('axios');

export class dashboard extends Component {
    constructor(props) {
        super(props)

        this.state = {
            candidates: [],
        }
    }
    componentDidMount() {
        axios.get('https://sodiotask.herokuapp.com/User/UsersDetails')
            .then(response => {
                // handle success
                this.setState({ candidates: response.data.data })

            })
            .catch(function (error) {
                // handle error
                console.log(error);
            })


    }
    handleShort = (id) => {

    }
    handlReject = (id) => {
        axios.put(`https://sodiotask.herokuapp.com/User/Update/UserDetails/:_id ${id}`, {
            "status": "rejected"
        })
            .then(function (response) {
                console.log(response);
            })
            .catch(function (error) {
                console.log(error);
            });


    }
    render() {
        console.log(this.state)
        var frontEnd = [];
        var nodeCand = [];
        var meanCand = [];
        var mearnCand = [];
        if (this.state.candidates.length != 0) {

            frontEnd = this.state.candidates.filter(function (candidate) {
                return candidate.jobTitle == 'frontend_developer';
            });
            nodeCand = this.state.candidates.filter(function (candidate) {
                return candidate.jobTitle == 'nodejs';
            });
            meanCand = this.state.candidates.filter(function (candidate) {
                return candidate.jobTitle == 'mean';
            });
            mearnCand = this.state.candidates.filter(function (candidate) {
                return candidate.jobTitle == 'full_stack_developer';
            });
        }

        return (
            <>
                <Container>
                    <Row>
                        <h3>Admin Dashbord</h3>
                    </Row>
                    <Row>




                        <Tab.Container id="left-tabs-example" defaultActiveKey="first">
                            <Container>
                                <Row >
                                    <Nav variant="pills" >
                                        <Nav.Item>
                                            <Nav.Link eventKey="first">Front-End Developer</Nav.Link>
                                        </Nav.Item>
                                        <Nav.Item>
                                            <Nav.Link eventKey="second">Node.js Developer</Nav.Link>
                                        </Nav.Item>
                                        <Nav.Item>
                                            <Nav.Link eventKey="third">MEAN stack Developer</Nav.Link>
                                        </Nav.Item>
                                        <Nav.Item>
                                            <Nav.Link eventKey="four">Fullstack Developer</Nav.Link>
                                        </Nav.Item>
                                    </Nav>
                                </Row>
                                <Row >

                                    <Tab.Content>
                                        <Tab.Pane eventKey="first">
                                            <h3>Front-End Developers</h3>
                                            <p>Lists of candidates applied for Frontend development</p>
                                            <Table striped bordered hover>
                                                <thead>
                                                    <tr>
                                                        <th>#</th>
                                                        <th>Name</th>
                                                        <th>Technical Skills</th>
                                                        <th>Experience</th>
                                                        <th>Applied Date</th>
                                                        <th>View Details</th>
                                                        <th>Update Application Status</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    {frontEnd.map(a =>
                                                        <tr>
                                                            <td>1</td>
                                                            <td>{a.name}</td>
                                                            <td>{a.skills}</td>
                                                            <td>{a.experience}</td>
                                                            <td>{a.appliedDate}</td>
                                                            <td><Button variant="info" >View Details</Button></td>
                                                            {a.status == "applied" ? <td> <Button variant="success" onClick={this.handleShort(a._id)}>Shortlist</Button> <Button onClick={this.handlReject(a._id)} variant="danger">Reject</Button></td> : null}
                                                            {a.status == "shortlisted" ? <td> <Button variant="success" >Shortlisted</Button> </td> : null}
                                                            {a.status == "rejected" ? <td> <Button variant="danger">Reject</Button> </td> : null}
                                                        </tr>
                                                    )}


                                                </tbody>
                                            </Table>


                                        </Tab.Pane>
                                        <Tab.Pane eventKey="second">
                                            <h3>Node.js Developers</h3>
                                            <p>Lists of candidates applied for Node.js development</p>
                                            <Table striped bordered hover>
                                                <thead>
                                                    <tr>
                                                        <th>#</th>
                                                        <th>Name</th>
                                                        <th>Technical Skills</th>
                                                        <th>Experience</th>
                                                        <th>Applied Date</th>
                                                        <th>View Details</th>
                                                        <th>Update Application Status</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    {nodeCand.map(a =>
                                                        <tr>
                                                            <td>1</td>
                                                            <td>{a.name}</td>
                                                            <td>{a.skills}</td>
                                                            <td>{a.experience}</td>
                                                            <td>{a.appliedDate}</td>
                                                            <td><Button variant="info" >View Details</Button></td>
                                                            {a.status == "applied" ? <td> <Button variant="success" onClick={this.handleShort(a._id)}>Shortlist</Button> <Button onClick={this.handlReject(a._id)} variant="danger">Reject</Button></td> : null}
                                                            {a.status == "shortlisted" ? <td> <Button variant="success" >Shortlisted</Button> </td> : null}
                                                            {a.status == "rejected" ? <td> <Button variant="danger">Reject</Button> </td> : null}

                                                        </tr>
                                                    )}


                                                </tbody>
                                            </Table>

                                        </Tab.Pane>
                                        <Tab.Pane eventKey="third">
                                            <h3>MEAN Satck  Developers</h3>
                                            <p>Lists of candidates applied for MEAN Satck development</p>
                                            <Table striped bordered hover>
                                                <thead>
                                                    <tr>
                                                        <th>#</th>
                                                        <th>Name</th>
                                                        <th>Technical Skills</th>
                                                        <th>Experience</th>
                                                        <th>Applied Date</th>
                                                        <th>View Details</th>
                                                        <th>Update Application Status</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    {meanCand.map(a =>
                                                        <tr>
                                                            <td>1</td>
                                                            <td>{a.name}</td>
                                                            <td>{a.skills}</td>
                                                            <td>{a.experience}</td>
                                                            <td>{a.appliedDate}</td>
                                                            <td><Button variant="info" >View Details</Button></td>
                                                            {a.status == "applied" ? <td> <Button variant="success" onClick={this.handleShort(a._id)}>Shortlist</Button> <Button onClick={this.handlReject(a._id)} variant="danger">Reject</Button></td> : null}
                                                            {a.status == "shortlisted" ? <td> <Button variant="success" >Shortlisted</Button> </td> : null}
                                                            {a.status == "rejected" ? <td> <Button variant="danger">Reject</Button> </td> : null}
                                                        </tr>
                                                    )}


                                                </tbody>
                                            </Table>

                                        </Tab.Pane>
                                        <Tab.Pane eventKey="four">
                                            <h3>Full Stack Developers</h3>
                                            <p>Lists of candidates applied for Full Stack development</p>
                                            <Table striped bordered hover>
                                                <thead>
                                                    <tr>
                                                        <th>#</th>
                                                        <th>Name</th>
                                                        <th>Technical Skills</th>
                                                        <th>Experience</th>
                                                        <th>Applied Date</th>
                                                        <th>View Details</th>
                                                        <th>Update Application Status</th>
                                                    </tr>
                                                </thead>
                                                <tbody>
                                                    {mearnCand.map(a =>
                                                        <tr>
                                                            <td>1</td>
                                                            <td>{a.name}</td>
                                                            <td>{a.skills}</td>
                                                            <td>{a.experience}</td>
                                                            <td>{a.appliedDate}</td>
                                                            <td><Button variant="info" >View Details</Button></td>
                                                            {a.status == "applied" ? <td> <Button variant="success" onClick={this.handleShort(a._id)}>Shortlist</Button> <Button onClick={this.handlReject(a._id)} variant="danger">Reject</Button></td> : null}
                                                            {a.status == "shortlisted" ? <td> <Button variant="success" >Shortlisted</Button> </td> : null}
                                                            {a.status == "rejected" ? <td> <Button variant="danger">Reject</Button> </td> : null}
                                                        </tr>
                                                    )}


                                                </tbody>
                                            </Table>

                                        </Tab.Pane>
                                    </Tab.Content>
                                </Row>
                            </Container>
                        </Tab.Container>
                    </Row>
                </Container>

            </>
        )
    }
}

export default dashboard
