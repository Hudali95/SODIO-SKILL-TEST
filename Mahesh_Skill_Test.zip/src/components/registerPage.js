import React, { Component } from 'react'
import { Container, Col, Row, Button, Form } from 'react-bootstrap'
const axios = require('axios');


class registerPage extends Component {
    constructor(props) {
        super(props)

        this.state = {
            name: '',
            email: '',
            phone: '',
            for: '',
            skills: '',
            experience: '',
            errMasg: '',

        }
    }
    handleChange = (e) => {

        this.setState({ [e.target.name]: e.target.value })

    }
    handleSubmit = (e) => {
        e.preventDefault()
        var errMasg = ''
        if (this.state.name === '' || this.state.email === '' || this.state.phone === '' || this.state.for === '' || this.state.skills === '' || this.state.experience === '') {
            errMasg = "Fields cannot be empty";
        } else {
            errMasg = "ok"
        }
        this.setState({ errMasg })
        if (errMasg === "ok") {
            var ndata = { name: this.state.name, email: this.state.email, phone: this.state.phone, skills: this.state.skills, jobTitle: this.state.for, experience: this.state.experience }
            var data = JSON.stringify(ndata)
            console.log(data)
            axios.post('https://sodiotask.herokuapp.com/User/Registration', data)
                .then(function (response) {
                    console.log(response);
                })
                .catch(function (error) {
                    console.log(error);
                });
        }

    }

    render() {
        return (
            <>
                <Container fluid="true" style={{ height: "100vh", backgroundColor: "#f0134d" }}>
                    <Container style={{ height: "100vh", width: "60%", margin: "auto", backgroundColor: "#f0134d" }}>
                        <Row className="text-center  pt-5 text-white" style={{ height: "15vh" }}>
                            <h3>Apply for jobs</h3>
                        </Row>

                        <Row style={{ height: "85vh", margin: "0", backgroundColor: "#fff", overflow: "hidden" }}>
                            <Form className="w-100 ml-2 mr-2 pt-5" onSubmit={this.handleSubmit}>
                                {this.state.errMasg != '' ? <Form.Group as={Row} className="text-danger m-0">{this.state.errMasg}</Form.Group> : null}
                                <Form.Group as={Row} className="m-0 pb-3" >
                                    <Form.Label column sm="4">
                                        Fullname
                                   </Form.Label>
                                    <Col sm="8">
                                        <Form.Control type="text" name="name" placeholder="Fullname" value={this.state.name} onChange={this.handleChange} />
                                    </Col>
                                </Form.Group>

                                <Form.Group as={Row} className=" m-0 pb-3" >
                                    <Form.Label column sm="4">
                                        Email Adddress
                                   </Form.Label>
                                    <Col sm="8">
                                        <Form.Control type="email" name="email" placeholder="example@gmail.com" value={this.state.email} onChange={this.handleChange} />
                                    </Col>
                                </Form.Group>

                                <Form.Group as={Row} className=" m-0 pb-3" >
                                    <Form.Label column sm="4">
                                        Contact number
                                   </Form.Label>
                                    <Col sm="8">
                                        <Form.Control type="number" name="phone" placeholder="Phone Number" value={this.state.phone} onChange={this.handleChange} />
                                    </Col>
                                </Form.Group>

                                <Form.Group as={Row} className=" m-0 pb-3">
                                    <Form.Label column sm="4">
                                        Applying for
                                   </Form.Label>
                                    <Col sm="8">
                                        <Form.Control type="text" as="select" name="for" placeholder="Applying For" value={this.state.for} onChange={this.handleChange}>

                                            <option>Frontend Development</option>
                                            <option>Node.js Development</option>
                                            <option>MEARN stack Development</option>
                                            <option>Full Stack</option>
                                        </Form.Control>
                                    </Col>
                                </Form.Group>

                                <Form.Group as={Row} className=" m-0 pb-3" >
                                    <Form.Label column sm="4">
                                        Experience
                                   </Form.Label>
                                    <Col sm="8">
                                        <Form.Control type="text" name="experience" placeholder="Experience" value={this.state.experience} onChange={this.handleChange} />
                                    </Col>
                                </Form.Group>

                                <Form.Group as={Row} className=" m-0 pb-3" >
                                    <Form.Label column sm="4">
                                        Technical Skills
                                   </Form.Label>
                                    <Col sm="8">
                                        <Form.Control type="text" name="skills" className="border" placeholder="Technical Skills" value={this.state.skills} onChange={this.handleChange} />
                                    </Col>
                                </Form.Group>

                                <Form.Group as={Row} className=" m-0 pb-3">

                                    <Col sm="8" className="pt-4" >
                                        <Form.Control type="submit" className="border bg-info text-white" style={{ width: "40%" }} value="Send Application" />
                                    </Col>
                                </Form.Group>
                            </Form>
                        </Row>
                    </Container>
                </Container>

            </>
        )
    }
}
export default registerPage